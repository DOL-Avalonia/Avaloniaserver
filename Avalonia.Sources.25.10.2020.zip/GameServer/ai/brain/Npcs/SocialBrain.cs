﻿/*
 * DAWN OF LIGHT - The first free open source DAoC server emulator
 *
 * This program is free software; you can redistribute it and/or
 * modify it under the terms of the GNU General Public License
 * as published by the Free Software Foundation; either version 2
 * of the License, or (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.
 *
 */
using DOL.GS;

namespace DOL.AI.Brain
{
    /// <summary>
    /// Proof of concept.
    /// A brain that will BAF (Bring-A-Friend) when nearby livings
    /// are attacked.
    /// <author>Aredhel</author>
    /// </summary>
    public class SocialBrain : AggressiveBrain
    {
        /// <summary>
        /// Come to this living's aid.
        /// </summary>
        /// <param name="target"></param>
        /// <param name="attacker"></param>
        protected override void OnLivingAttacked(GameLiving target, GameLiving attacker)
        {
            base.OnLivingAttacked(target, attacker);

            if (target.IsWithinRadius(Body, AggressionRange))
            {
                EngageOn(attacker);
            }
        }
    }
}
