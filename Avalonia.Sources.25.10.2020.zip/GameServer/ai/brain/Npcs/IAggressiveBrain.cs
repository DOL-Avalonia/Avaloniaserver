﻿namespace DOL.AI.Brain
{
    public interface IAggressiveBrain
    {
    }
}
