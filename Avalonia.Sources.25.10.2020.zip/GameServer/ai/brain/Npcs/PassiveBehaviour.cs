﻿using DOL.GS;

namespace DOL.AI.Brain
{
    public class PassiveBehaviour : IAttackBehaviour
    {
        public void Attack(GameObject target)
        {
        }

        public void Retreat()
        {
        }
    }
}
